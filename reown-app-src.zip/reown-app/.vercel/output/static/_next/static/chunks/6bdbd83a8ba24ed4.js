__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/1f7143bff62197d7.js",
  "static/chunks/turbopack-83dd2fce31b3809d.js"
])
